import React, { useState } from "react";
import { MdDelete } from "react-icons/md";

const App = () => {
  const [Input, setInput] = useState("");
  const [list, setList] = useState([]);

  const handleSubmit = (e) => {
    list.push(Input);
    localStorage.setItem("list", JSON.stringify(list)); //to convert objects into JSON.
    // ( ... ) allows us to quickly copy all or part of an existing array or object into another array or object.
    setInput("");
    // The preventDefault() method cancels the event if it is cancelable, meaning that the default action that belongs to the event will not occur.
    e.preventDefault();
  };

  const handleDelete = (id) => {
    //removes from a specific Array index This method modifies the original array and returns the removed elements as a new array.
    //number 1 is Number of items to be removed.
    list.splice(id, 1);
    //update new list
    setList([...list]);
  };

  return (
    <>
      <input
        type="text"
        placeholder="Enter list"
        value={Input}
        onChange={(e) => setInput(e.target.value)}
      />
      <button type="submit" onClick={handleSubmit}>
        Add
      </button>
      <div>
        {list.map((item, id) => (
          <div key={id}>
            <span>{item} </span>
            <button onClick={() => handleDelete(id)}>
              <MdDelete />
            </button>
          </div>
        ))}
      </div>
    </>
  );
};

export default App;
