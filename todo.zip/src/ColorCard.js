import React from "react";

const ColorCard = () => {
  const Card = [
    {
      name: "red",
      color: "#FF0000",
    },
    {
      name: "Cyan",
      color: "#00FFFF",
    },
    {
      name: "Blue",
      color: "#0000FF",
    },
    {
      name: "LightBlue",
      color: "#ADD8E6",
    },
    {
      name: "Purple",
      color: "#800080",
    },
    {
      name: "Yellow",
      color: "#FFFF00",
    },
    {
      name: "Magenta",
      color: "#FF00FF",
    },
    {
      name: "Orange",
      color: "#FFA500",
    },
    {
      name: "Brown",
      color: "#A52A2A",
    },
    {
      name: "Olive",
      color: "#808000",
    },
    {
      name: "bisque",
      color: "#ffe4c4",
    },
    {
      name: "blueviolet",
      color: "#8a2be2",
    },
  ];

  return (
    <>
      {Card.map((val) => {
        const { name, color } = val;
        return (
          <div
            className="box"
            style={{
              // Template literals
              backgroundColor: `${color}`,
            }}
          >
            {/* assigned name and color string value */}
            <h1 className="text">{name}</h1>
            <h2 className="text2">{color}</h2>
          </div>
        );
      })}
    </>
  );
};

export default ColorCard;
